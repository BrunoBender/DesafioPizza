package pacote;

public class Teste {

}
